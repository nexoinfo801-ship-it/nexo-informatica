SITE NEXO INFORMÁTICA

Para abrir:
1. Extraia o arquivo ZIP.
2. Abra o arquivo index.html com Google Chrome, Edge ou outro navegador.

Para publicar na internet, envie todos os arquivos desta pasta para uma hospedagem de sites.

Contato configurado:
WhatsApp: (14) 99835-6762
Instagram: @nexoinfo801
Facebook: nexoinformatica
